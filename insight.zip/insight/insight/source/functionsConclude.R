#Conclusion1
callConclude1 <- function(){
h3(tags$ul(
    tags$li("The most common words unique to Manhattan listings are - midtown, central, park, harlem, times, square."),
    tags$li("If looking for an Airbnb in Brooklyn, people could type in the words - brownstone, bushwick, greenpoint."),
    tags$li("Queens listings mostly contain these words - queens, astoria, jfk."),
    tags$li("With the Yankees stadium located in Bronx, the most frequent words in Bronx listings are - bronx, yankee, stadium."),
    tags$li("Staten Island is famous for its ferry and its proximity to the beach. Tourists could look for listings using the words - staten, island, ferry, beach."),
    tags$li("Words which are repeated in all of NYC's Airbnb listings are - sunny, modern, cozy, bright, beautiful, apartment, bedroom, charming, loft, studio, subway, nyc, quiet, clean."),
    tags$li("Interestingly, another word which appears in most listings of all neighborhoods is - Manhattan, in the context of `close to Manhattan`. Airbnbs attract customers by listing the description of a room as being close to Manhattan - the MOST HAPPENING place in NYC.")))
}

